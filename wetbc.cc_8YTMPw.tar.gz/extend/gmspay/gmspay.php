<?php

namespace gmspay;

use think\Db;

class gmspay
{
	
	private $mch_id = '300001999';
	private $payKey = '70f6dbc54e7e46f6917fe93feacb20d5';
	private $withdrawalKey = 'PAFLAZ4MJC7UGQFSDZNSSP9Y6ABGT3SK';
	
	public $bankList = [
		['code' => 'KBANK', 'name' => 'KASIKORNBANK PCL'],
		['code' => 'BBL', 'name' => 'BANGKOK BANK PUBLIC COMPANY LTD.'],
		['code' => 'BAAC', 'name' => 'BANK FOR AGRICULTURE AND AGRICULTURAL CO-OPERATIVES'],
		['code' => 'BOA', 'name' => 'BANK OF AMERICA NT&SA'],
		['code' => 'BAY', 'name' => 'BANK OF AYUDHAYA PUBLIC COMPANY LTD.'],
		['code' => 'BOC', 'name' => 'Bank of China (Thai) PCL'],
		['code' => 'BNPP', 'name' => 'BNP PARIBAS BANGKOK BRANCH'],
		['code' => 'CIMB', 'name' => 'CIMB THAI BANK PUBLIC COMPANY LTD.'],
		['code' => 'CITI', 'name' => 'CITI BANK N.A.'],
		['code' => 'DB', 'name' => 'Deutsche Bank AG'],
		['code' => 'GHB', 'name' => 'GOVERNMENT HOUSING BANK'],
		['code' => 'ICBC', 'name' => 'INDUSTRIAL AND COMMERCIAL BANK OF CHINA (THAI) PCL'],
		['code' => 'TIBT', 'name' => 'ISLAMIC BANK OF THAILAND'],
		['code' => 'CHAS', 'name' => 'JPMorgan Chase Bank, Bangkok Branch'],
		['code' => 'KKB', 'name' => 'KIATNAKIN BANK PCL'],
		['code' => 'KTB', 'name' => 'KRUNG THAI BANK PUBLIC COMPANY LTD.'],
		['code' => 'LHBA', 'name' => 'Land and Houses Bank'],
		['code' => 'MEGA', 'name' => 'MEGA INTERNATIONAL COMMERCIAL BANK'],
		['code' => 'MHCB', 'name' => 'MIZUHO CORPORATE BANK'],
		['code' => 'SCBT', 'name' => 'STANDARD CHARTERED BANK THAI PCL.'],
		['code' => 'SMTB', 'name' => 'Sumitomo Mitsui Trust Bank (Thai) PCL.'],
		['code' => 'TBNK', 'name' => 'Thanachart Bank Public Company Limited'],
		['code' => 'GSB', 'name' => 'THE GOVERNMENT SAVING BANK'],
		['code' => 'HSBC', 'name' => 'THE HONGKONG & SHANGHAI CORPORATION LTD.'],
		['code' => 'SCB', 'name' => 'THE SIAM COMMERCIAL BANK PUBLIC COMPANY'],
		['code' => 'SMBC', 'name' => 'THE SUMITOMO MITSU BANKING CORPORATION'],
		['code' => 'TCRB', 'name' => 'THE THAI CREDIT RETAIL BANK'],
		['code' => 'TISCO', 'name' => 'TISCO Bank PCL'],
		['code' => 'TMB', 'name' => 'TMB BANK PUBLIC COMPANY LTD.'],
		['code' => 'UOB', 'name' => 'UNITED OVERSEAS BANK (THAI) PUBLIC COMPANY LTD.'],
		['code' => 'EXIM', 'name' => 'EXPORT–IMPORT BANK OF THAILAND'],
		['code' => 'BOT', 'name' => 'BANK OF THAILAND'],
	];
	
	
	// 支付账号：07601541479 CPF
	// private $user_id = '210813BL87';
	// private $key = '3d79d7d5e19c4674b635c532819d4788';
	// private $domain;
	
	public function __construct()
	{
		$this->domain = $_SERVER['SERVER_NAME'] ? "https://" . $_SERVER['SERVER_NAME'] : "https://" . $_SERVER['HTTP_HOST'];
	}
	
	
	/**
	 * 发起支付
	 * $num         金额
	 * $order_no  订单号
	 */
	public function payment($num, $order_no)
	{
		$url = 'https://api.gmspay.net/pay/web';
		$data['version'] = "1.0";
		$data['mch_id'] = $this->mch_id;                                                     //商户接口id
		$data['notify_url'] = $this->domain . '/payment/Notify/gmspay_notify';               //异步回调地址
		$data['page_url'] = $this->domain . '/index/my/index';                               //同步跳转地址
		$data['mch_order_no'] = $order_no;                                                   //商户订单号 不可重复
		$data['pay_type'] = "320";                                                           //默认：321网银 320扫码
		$data['trade_amount'] = $num;                                                       //金额 单位:元
		$data['order_date'] = date('Y-m-d H:i:s', time());                             //时间
		$data['goods_name'] = 'goods';                                                       //商品名称
		
		$data['sign'] = $this->sign($data,$this->payKey);
		$data['sign_type'] = 'MD5';                                                          //签名方式
		return $this->post($url, $data, 'form');
	}
	
	/**
	 * 回调验证
	 */
	public function pay_notify($data,$type='p')
	{
		$sign = $data['sign'];
		$key = $this->payKey;
		if($type = 'w'){
			$key = $this->withdrawalKey;
		}
		
		unset($data['sign'], $data['signType']);
		
		if ($this->sign($data,$key) === $sign) {
			return true;
		}
		return false;
	}
	
	
	/**
	 * 发起代付
	 * @param $uid
	 * @param $num
	 * @return mixed
	 * @throws \think\db\exception\DataNotFoundException
	 * @throws \think\db\exception\ModelNotFoundException
	 * @throws \think\exception\DbException
	 */
	public function withdrawal($wdata)
	{
		$url = 'https://api.gmspay.net/pay/transfer';
		$data['mch_id'] = $this->mch_id;
		$data['mch_transferId'] = $wdata['order_num'];                           //订单号
		$data['transfer_amount'] = (int)$wdata['payment'];                    //金额
		$data['apply_date'] = date('Y-m-d H:i:s', time());               //时间
		$data['bank_code'] = $wdata['bank_type'];                               //银行代码
		$data['receive_name'] = $wdata['bank'];                                 //银行名称
		$data['receive_account'] = $wdata['card'];                              //银行账号
		$data['back_url'] = $this->domain . '/payment/Notify/gmspay_withdrawal_notify';    //回调地址
		$data['sign'] = $this->sign($data,$this->withdrawalKey);                                     //签名
		$data['sign_type'] ='MD5';
		return $this->post($url, $data,'form');
	}
	

	
	
	/**生成签名 */
	private function sign($arr,$key)
	{
		
		ksort($arr);
		$arr['key'] = $key;
		$strData = '';
		foreach ($arr as $k => $v) {
			$strData .= $k . '=' . $v . '&';
		}
		
		return md5(trim($strData, '&'));
		
		
	}
	
	public  function getBankName($bankCode){
		
		$bankName = '';
		foreach ($this->bankList as $value){
			if($value['code'] == $bankCode ){
				$bankName = $value['name'];
				break;
			}
		}
		
		return $bankName;
	}
	
	private function post($url, $data, $type = "json")
	{
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url); //支付请求地址
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		curl_setopt($ch, CURLOPT_POST, true);
		curl_setopt($ch, CURLOPT_HEADER, false);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		
		
		if ($type == 'json') {
			$data = json_encode($data);
			curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json', 'Content-Length: ' . strlen($data)]);
		} else {
			$data = http_build_query($data);
		}
		
		curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
		$response = curl_exec($ch);
		curl_close($ch);
		return json_decode($response, true);
		
	}
}
