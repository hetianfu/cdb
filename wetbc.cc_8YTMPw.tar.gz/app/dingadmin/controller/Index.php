<?php

namespace app\dingadmin\controller;

use think\facade\Db;
use app\BaseController;

class Index extends Base
{
	
	public function index()
	{
		return view();
	}
	
	
	public function main()
	{
		//获取服务器信息,超全局变量:$_SERVER
		$system = [
			'ip' => $_SERVER['SERVER_ADDR'],            //获取服务器IP地址
			'host' => $_SERVER['SERVER_NAME'],          //服务器域名/主机名
			'os' => PHP_OS,                             //服务器操作系统/php_uname
			'server' => $_SERVER['SERVER_SOFTWARE'],    //运行环境
			'port' => $_SERVER['SERVER_PORT'],          //服务器端口
			'php_ver' => PHP_VERSION,                   //php版本
			'mysql_ver' => Db::query('select version() as ver')[0]['ver'],//数据库版本
			'database' => config('database')['connections']['mysql']['database'],//数据库名称
		];
		//获取登录日志信息
		$logRes = Db::name('login_record')->order('logintime desc')->where('uid', session('admin_auth.id'))->limit(10)->select();
		

	
		return view('main', [
			'system' => $system,
			'log' => $logRes,
			'register' => self::countRegister(),
			'rujin'=>self::sumRujin(),
			'chujin'=>self::sumChujin()
		]);
		
	}
	
	
	/**
	 * 统计入金
	 * @return array
	 */
	public function countRegister()
	{
		//总会员
		$data['count'] = Db::name('user')->count();
		
		//今日
		$start = strtotime(date("Y-m-d"),time());
		$end = strtotime('+1 day',$start-1);
		$data['today'] = Db::name('user')->whereBetweenTime('reg_time',$start,$end)->count();
	
		//昨天
		$start= strtotime('-1 day',strtotime(date("Y-m-d"),time()));
		$end = strtotime(date("Y-m-d"),time()) - 1;
		$data['yesterday'] = Db::name('user')->whereBetweenTime('reg_time',$start,$end)->count();
		return $data;
	}
	
	/**
	 * 统计入金
	 * @return array
	 */
	public function sumRujin(){
		//总入金
		$data['sum'] = Db::name('recharge')->where(['status'=>1])->sum('money');
		
		//今日
		$start = strtotime(date("Y-m-d"),time());
		$end = strtotime('+1 day',$start-1);
		$data['today'] = Db::name('recharge')->where(['status'=>1])->whereBetweenTime('addtime',$start,$end)->sum('money');
		
		//昨天
		$start= strtotime('-1 day',strtotime(date("Y-m-d"),time()));
		$end = strtotime(date("Y-m-d"),time()) - 1;
		$data['yesterday'] = Db::name('recharge')->where(['status'=>1])->whereBetweenTime('addtime',$start,$end)->sum('money');
		return $data;
	}
	
	
	/**
	 * 统计出金
	 * @return array
	 */
	public function sumChujin(){
		//总会员
		$data['sum'] = Db::name('withdrawal')->where(['status'=>1])->sum('money');
		
		//今日
		$start = strtotime(date("Y-m-d"),time());
		$end = strtotime('+1 day',$start-1);
		$data['today'] = Db::name('withdrawal')->where(['status'=>1])->whereBetweenTime('addtime',$start,$end)->sum('money');
		
		//昨天
		$start= strtotime('-1 day',strtotime(date("Y-m-d"),time()));
		$end = strtotime(date("Y-m-d"),time()) - 1;
		$data['yesterday'] = Db::name('withdrawal')->where(['status'=>1])->whereBetweenTime('addtime',$start,$end)->sum('money');
		return $data;
	}
}