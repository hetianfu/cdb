<?php

namespace app\index\controller;

use jiesuan\Jiesuan;
use think\facade\Db;
use think\facade\Log;

class Api
{
  

	
	
}